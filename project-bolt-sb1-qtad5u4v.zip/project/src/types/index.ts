export interface Camera {
  id: string;
  name: string;
  ipAddress: string;
  username: string;
  password: string;
  streamType: 'RTSP' | 'HTTP';
  location: string;
  description: string;
  status: 'online' | 'offline' | 'error';
}

export interface Recording {
  id: string;
  cameraId: string;
  timestamp: string;
  duration: number;
  thumbnailUrl: string;
  fileUrl: string;
}

export interface HistoryEvent {
  id: string;
  cameraId: string;
  timestamp: string;
  eventType: 'connection' | 'recording' | 'error' | 'config';
  description: string;
}

export interface SystemConfig {
  language: string;
  autoLoadCameras: boolean;
  defaultRecordingFormat: string;
  storageLocation: string;
  theme: 'light' | 'dark';
  maxFps: number;
}

export type Language =
  | 'hindi'
  | 'bengali'
  | 'telugu'
  | 'marathi'
  | 'tamil'
  | 'urdu'
  | 'gujarati'
  | 'kannada'
  | 'malayalam'
  | 'odia'
  | 'punjabi'
  | 'assamese'
  | 'sanskrit'
  | 'english';