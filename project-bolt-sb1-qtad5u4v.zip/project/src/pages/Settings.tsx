import React, { useState } from 'react';
import { Save, Upload, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Language } from '../types';

const Settings = () => {
  const { config, updateConfig } = useApp();
  const [isApplying, setIsApplying] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const languages: { code: Language; name: string }[] = [
    { code: 'english', name: 'English' },
    { code: 'hindi', name: 'हिन्दी' },
    { code: 'bengali', name: 'বাংলা' },
    { code: 'telugu', name: 'తెలుగు' },
    { code: 'marathi', name: 'मराठी' },
    { code: 'tamil', name: 'தமிழ்' },
    { code: 'urdu', name: 'اردو' },
    { code: 'gujarati', name: 'ગુજરાતી' },
    { code: 'kannada', name: 'ಕನ್ನಡ' },
    { code: 'malayalam', name: 'മലയാളം' },
    { code: 'odia', name: 'ଓଡ଼ିଆ' },
    { code: 'punjabi', name: 'ਪੰਜਾਬੀ' },
    { code: 'assamese', name: 'অসমীয়া' },
    { code: 'sanskrit', name: 'संस्कृतम्' },
  ];

  const handleExportConfig = () => {
    const dataStr = JSON.stringify(config, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = 'camera-config.json';

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportConfig = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const config = JSON.parse(e.target?.result as string);
          updateConfig(config);
          setMessage({ type: 'success', text: 'Configuration imported successfully' });
        } catch (error) {
          setMessage({ type: 'error', text: 'Error parsing config file' });
        }
      };
      reader.readAsText(file);
    }
  };

  const handleLanguageChange = (newLanguage: Language) => {
    updateConfig({ language: newLanguage });
    setMessage({ type: 'success', text: 'Language updated successfully' });
  };

  const handleApplySettings = async () => {
    setIsApplying(true);
    try {
      // Only apply settings that require camera restart
      if (config.maxFps !== undefined) {
        const response = await fetch('/api/settings', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            maxFps: config.maxFps,
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to apply camera settings');
        }
      }
      
      setMessage({ type: 'success', text: 'Settings applied successfully' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to apply camera settings' });
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Settings</h1>
        <div className="flex space-x-4">
          <button
            onClick={handleExportConfig}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Save className="h-5 w-5 mr-2" />
            Export Config
          </button>
          <label className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 cursor-pointer">
            <Upload className="h-5 w-5 mr-2" />
            Import Config
            <input
              type="file"
              accept=".json"
              onChange={handleImportConfig}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {message && (
        <div
          className={`mb-4 p-4 rounded-md ${
            message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}
        >
          {message.text}
        </div>
      )}

      <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium text-gray-900">Language Settings</h3>
          <div className="mt-4">
            <select
              value={config.language}
              onChange={(e) => handleLanguageChange(e.target.value as Language)}
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            >
              {languages.map(({ code, name }) => (
                <option key={code} value={code}>
                  {name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium text-gray-900">Camera Settings</h3>
          <div className="mt-4 space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-900">Maximum FPS</label>
              <input
                type="number"
                min="1"
                max="60"
                value={config.maxFps}
                onChange={(e) => updateConfig({ maxFps: parseInt(e.target.value) })}
                className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              <p className="mt-1 text-sm text-gray-500">
                Maximum frames per second for camera streams (1-60)
              </p>
            </div>
          </div>
        </div>

        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg font-medium text-gray-900">System Preferences</h3>
          <div className="mt-4 space-y-4">
            <div className="flex items-center justify-between">
              <span className="flex-grow flex flex-col">
                <span className="text-sm font-medium text-gray-900">Auto-load cameras</span>
                <span className="text-sm text-gray-500">
                  Automatically load cameras from config file on startup
                </span>
              </span>
              <button
                type="button"
                onClick={() => updateConfig({ autoLoadCameras: !config.autoLoadCameras })}
                className={`${
                  config.autoLoadCameras ? 'bg-indigo-600' : 'bg-gray-200'
                } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
              >
                <span
                  className={`${
                    config.autoLoadCameras ? 'translate-x-5' : 'translate-x-0'
                  } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                />
              </button>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-900">Default Recording Format</label>
              <select
                value={config.defaultRecordingFormat}
                onChange={(e) => updateConfig({ defaultRecordingFormat: e.target.value })}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="mp4">MP4</option>
                <option value="mkv">MKV</option>
                <option value="avi">AVI</option>
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-900">Storage Location</label>
              <input
                type="text"
                value={config.storageLocation}
                onChange={(e) => updateConfig({ storageLocation: e.target.value })}
                className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-gray-900">Theme</label>
              <select
                value={config.theme}
                onChange={(e) => updateConfig({ theme: e.target.value as 'light' | 'dark' })}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
          </div>
        </div>

        <div className="px-4 py-4 sm:px-6">
          <button
            onClick={handleApplySettings}
            disabled={isApplying}
            className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {isApplying ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Applying Settings...
              </>
            ) : (
              <>
                <Check className="h-5 w-5 mr-2" />
                Apply Settings
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;