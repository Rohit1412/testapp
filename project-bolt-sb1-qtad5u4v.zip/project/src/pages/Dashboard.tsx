import React, { useState } from 'react';
import { Plus, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AddCameraModal } from '../components/AddCameraModal';

const Dashboard = () => {
  const { cameras } = useApp();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Camera Dashboard</h1>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add Camera
        </button>
      </div>

      {cameras.length === 0 ? (
        <div className="text-center py-12">
          <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No cameras</h3>
          <p className="mt-1 text-sm text-gray-500">Get started by adding a new camera.</p>
          <div className="mt-6">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Camera
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {cameras.map(camera => (
            <div
              key={camera.id}
              className="bg-white overflow-hidden shadow rounded-lg divide-y divide-gray-200"
            >
              <div className="px-4 py-5 sm:p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900">{camera.name}</h3>
                  <span
                    className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      camera.status === 'online'
                        ? 'bg-green-100 text-green-800'
                        : camera.status === 'offline'
                        ? 'bg-gray-100 text-gray-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {camera.status}
                  </span>
                </div>
                <div className="mt-4 space-y-2">
                  <p className="text-sm text-gray-500">IP: {camera.ipAddress}</p>
                  <p className="text-sm text-gray-500">Location: {camera.location}</p>
                  <p className="text-sm text-gray-500">Stream: {camera.streamType}</p>
                </div>
              </div>
              <div className="px-4 py-4 sm:px-6">
                {/* Placeholder for camera feed */}
                <div className="bg-gray-100 h-48 rounded flex items-center justify-center">
                  <span className="text-gray-500">Camera Feed</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <AddCameraModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} />
    </div>
  );
};

export default Dashboard;