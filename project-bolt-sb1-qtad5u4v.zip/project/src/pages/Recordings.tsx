import React, { useState } from 'react';
import { Grid, List, Download, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Recordings = () => {
  const { recordings, cameras } = useApp();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const handleDownload = (recordingId: string) => {
    const recording = recordings.find(r => r.id === recordingId);
    if (recording) {
      // In a real application, this would trigger the actual download
      console.log('Downloading recording:', recording.fileUrl);
    }
  };

  const handleDelete = (recordingId: string) => {
    // In a real application, this would delete the recording
    console.log('Deleting recording:', recordingId);
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Recordings</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md ${
              viewMode === 'grid' ? 'bg-gray-200' : 'hover:bg-gray-100'
            }`}
          >
            <Grid className="h-5 w-5" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-md ${
              viewMode === 'list' ? 'bg-gray-200' : 'hover:bg-gray-100'
            }`}
          >
            <List className="h-5 w-5" />
          </button>
        </div>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {recordings.map(recording => {
            const camera = cameras.find(c => c.id === recording.cameraId);
            return (
              <div
                key={recording.id}
                className="bg-white overflow-hidden shadow rounded-lg"
              >
                <div className="relative">
                  <img
                    src={recording.thumbnailUrl}
                    alt="Recording thumbnail"
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                    <p className="text-white font-medium">{camera?.name}</p>
                  </div>
                </div>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">
                        {new Date(recording.timestamp).toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-500">
                        Duration: {Math.floor(recording.duration / 60)}:{(recording.duration % 60)
                          .toString()
                          .padStart(2, '0')}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleDownload(recording.id)}
                        className="p-2 text-gray-400 hover:text-gray-500"
                      >
                        <Download className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(recording.id)}
                        className="p-2 text-gray-400 hover:text-gray-500"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {recordings.map(recording => {
              const camera = cameras.find(c => c.id === recording.cameraId);
              return (
                <li key={recording.id}>
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <img
                          src={recording.thumbnailUrl}
                          alt="Recording thumbnail"
                          className="h-16 w-24 object-cover rounded"
                        />
                        <div className="ml-4">
                          <p className="text-sm font-medium text-indigo-600">{camera?.name}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(recording.timestamp).toLocaleString()}
                          </p>
                          <p className="text-sm text-gray-500">
                            Duration: {Math.floor(recording.duration / 60)}:{(recording.duration % 60)
                              .toString()
                              .padStart(2, '0')}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleDownload(recording.id)}
                          className="p-2 text-gray-400 hover:text-gray-500"
                        >
                          <Download className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => handleDelete(recording.id)}
                          className="p-2 text-gray-400 hover:text-gray-500"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Recordings;