export const translations = {
  english: {
    dashboard: {
      title: 'Camera Dashboard',
      addCamera: 'Add Camera',
      noCameras: 'No cameras',
      getStarted: 'Get started by adding a new camera.',
      cameraFeed: 'Camera Feed',
      status: 'Status',
      location: 'Location',
      streamType: 'Stream Type'
    },
    settings: {
      title: 'Settings',
      language: 'Language Settings',
      system: 'System Preferences',
      camera: 'Camera Settings',
      maxFps: 'Maximum FPS',
      autoLoad: 'Auto-load cameras',
      autoLoadDesc: 'Automatically load cameras from config file on startup',
      recordingFormat: 'Default Recording Format',
      storage: 'Storage Location',
      theme: 'Theme',
      apply: 'Apply Settings',
      applying: 'Applying Settings...',
      success: 'Settings applied successfully',
      error: 'Failed to apply settings'
    },
    common: {
      online: 'Online',
      offline: 'Offline',
      error: 'Error',
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      history: 'History',
      recordings: 'Recordings',
      export: 'Export',
      import: 'Import',
      apply: 'Apply'
    }
  },
  hindi: {
    dashboard: {
      title: 'कैमरा डैशबोर्ड',
      addCamera: 'कैमरा जोड़ें',
      noCameras: 'कोई कैमरा नहीं',
      getStarted: 'नया कैमरा जोड़कर शुरू करें।',
      cameraFeed: 'कैमरा फ़ीड',
      status: 'स्थिति',
      location: 'स्थान',
      streamType: 'स्ट्रीम प्रकार'
    },
    settings: {
      title: 'सेटिंग्स',
      language: 'भाषा सेटिंग्स',
      system: 'सिस्टम प्राथमिकताएं',
      camera: 'कैमरा सेटिंग्स',
      maxFps: 'अधिकतम FPS',
      autoLoad: 'स्वचालित लोड कैमरा',
      autoLoadDesc: 'स्टार्टअप पर कॉन्फ़िग फ़ाइल से कैमरा स्वचालित रूप से लोड करें',
      recordingFormat: 'डिफ़ॉल्ट रिकॉर्डिंग प्रारूप',
      storage: 'स्टोरेज स्थान',
      theme: 'थीम',
      apply: 'सेटिंग्स लागू करें',
      applying: 'सेटिंग्स लागू की जा रही हैं...',
      success: 'सेटिंग्स सफलतापूर्वक लागू की गईं',
      error: 'सेटिंग्स लागू करने में विफल'
    },
    common: {
      online: 'ऑनलाइन',
      offline: 'ऑफ़लाइन',
      error: 'त्रुटि',
      save: 'सहेजें',
      cancel: 'रद्द करें',
      delete: 'हटाएं',
      edit: 'संपादित करें',
      history: 'इतिहास',
      recordings: 'रिकॉर्डिंग',
      export: 'निर्यात',
      import: 'आयात',
      apply: 'लागू करें'
    }
  },
  bengali: {
    dashboard: {
      title: 'ক্যামেরা ড্যাশবোর্ড',
      addCamera: 'ক্যামেরা যোগ করুন',
      noCameras: 'কোন ক্যামেরা নেই',
      getStarted: 'নতুন ক্যামেরা যোগ করে শুরু করুন।',
      cameraFeed: 'ক্যামেরা ফিড',
      status: 'স্থিতি',
      location: 'অবস্থান',
      streamType: 'স্ট্রিম প্রকার'
    },
    settings: {
      title: 'সেটিংস',
      language: 'ভাষা সেটিংস',
      system: 'সিস্টেম পছন্দসমূহ',
      camera: 'ক্যামেরা সেটিংস',
      maxFps: 'সর্বোচ্চ FPS',
      autoLoad: 'স্বয়ংক্রিয় লোড ক্যামেরা',
      autoLoadDesc: 'স্টার্টআপে কনফিগ ফাইল থেকে স্বয়ংক্রিয়ভাবে ক্যামেরা লোড করুন',
      recordingFormat: 'ডিফল্ট রেকর্ডিং ফরম্যাট',
      storage: 'স্টোরেজ লোকেশন',
      theme: 'থিম',
      apply: 'সেটিংস প্রয়োগ করুন',
      applying: 'সেটিংস প্রয়োগ করা হচ্ছে...',
      success: 'সেটিংস সফলভাবে প্রয়োগ করা হয়েছে',
      error: 'সেটিংস প্রয়োগ করতে ব্যর্থ'
    },
    common: {
      online: 'অনলাইন',
      offline: 'অফলাইন',
      error: 'ত্রুটি',
      save: 'সংরক্ষণ',
      cancel: 'বাতিল',
      delete: 'মুছুন',
      edit: 'সম্পাদনা',
      history: 'ইতিহাস',
      recordings: 'রেকর্ডিং',
      export: 'রপ্তানি',
      import: 'আমদানি',
      apply: 'প্রয়োগ করুন'
    }
  },
  telugu: {
    dashboard: {
      title: 'కెమెరా డాష్‌బోర్డ్',
      addCamera: 'కెమెరా జోడించు',
      noCameras: 'కెమెరాలు లేవు',
      getStarted: 'కొత్త కెమెరాను జోడించడం ద్వారా ప్రారంభించండి.',
      cameraFeed: 'కెమెరా ఫీడ్',
      status: 'స్థితి',
      location: 'స్థానం',
      streamType: 'స్ట్రీమ్ రకం'
    },
    settings: {
      title: 'సెట్టింగ్‌లు',
      language: 'భాష సెట్టింగ్‌లు',
      system: 'సిస్టమ్ ప్రాధాన్యతలు',
      camera: 'కెమెరా సెట్టింగ్‌లు',
      maxFps: 'గరిష్ట FPS',
      autoLoad: 'స్వయంచాలక లోడ్ కెమెరాలు',
      autoLoadDesc: 'స్టార్టప్‌లో కాన్ఫిగ్ ఫైల్ నుండి స్వయంచాలకంగా కెమెరాలను లోడ్ చేయండి',
      recordingFormat: 'డిఫాల్ట్ రికార్డింగ్ ఫార్మాట్',
      storage: 'నిల్వ స్థానం',
      theme: 'థీమ్',
      apply: 'సెట్టింగ్‌లను వర్తింపజేయి',
      applying: 'సెట్టింగ్‌లు వర్తింపజేస్తోంది...',
      success: 'సెట్టింగ్‌లు విజయవంతంగా వర్తింపజేయబడ్డాయి',
      error: 'సెట్టింగ్‌లను వర్తింపజేయడంలో విఫలమైంది'
    },
    common: {
      online: 'ఆన్‌లైన్',
      offline: 'ఆఫ్‌లైన్',
      error: 'లోపం',
      save: 'సేవ్ చేయి',
      cancel: 'రద్దు చేయి',
      delete: 'తొలగించు',
      edit: 'సవరించు',
      history: 'చరిత్ర',
      recordings: 'రికార్డింగ్‌లు',
      export: 'ఎగుమతి',
      import: 'దిగుమతి',
      apply: 'వర్తింపజేయి'
    }
  },
  tamil: {
    dashboard: {
      title: 'கேமரா டாஷ்போர்டு',
      addCamera: 'கேமரா சேர்',
      noCameras: 'கேமராக்கள் இல்லை',
      getStarted: 'புதிய கேமராவைச் சேர்த்து தொடங்குங்கள்.',
      cameraFeed: 'கேமரா ஊட்டம்',
      status: 'நிலை',
      location: 'இடம்',
      streamType: 'ஸ்ட்ரீம் வகை'
    },
    settings: {
      title: 'அமைப்புகள்',
      language: 'மொழி அமைப்புகள்',
      system: 'கணினி விருப்பங்கள்',
      camera: 'கேமரா அமைப்புகள்',
      maxFps: 'அதிகபட்ச FPS',
      autoLoad: 'தானியங்கி ஏற்றம் கேமராக்கள்',
      autoLoadDesc: 'தொடக்கத்தில் கட்டமைப்பு கோப்பிலிருந்து தானாகவே கேமராக்களை ஏற்றவும்',
      recordingFormat: 'இயல்புநிலை பதிவு வடிவம்',
      storage: 'சேமிப்பக இடம்',
      theme: 'தீம்',
      apply: 'அமைப்புகளைப் பயன்படுத்து',
      applying: 'அமைப்புகள் பயன்படுத்தப்படுகின்றன...',
      success: 'அமைப்புகள் வெற்றிகரமாக பயன்படுத்தப்பட்டன',
      error: 'அமைப்புகளைப் பயன்படுத்த முடியவில்லை'
    },
    common: {
      online: 'ஆன்லைன்',
      offline: 'ஆஃப்லைன்',
      error: 'பிழை',
      save: 'சேமி',
      cancel: 'ரத்துசெய்',
      delete: 'நீக்கு',
      edit: 'திருத்து',
      history: 'வரலாறு',
      recordings: 'பதிவுகள்',
      export: 'ஏற்றுமதி',
      import: 'இறக்குமதி',
      apply: 'பயன்படுத்து'
    }
  },
  kannada: {
    dashboard: {
      title: 'ಕ್ಯಾಮೆರಾ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
      addCamera: 'ಕ್ಯಾಮೆರಾ ಸೇರಿಸಿ',
      noCameras: 'ಯಾವುದೇ ಕ್ಯಾಮೆರಾಗಳಿಲ್ಲ',
      getStarted: 'ಹೊಸ ಕ್ಯಾಮೆರಾ ಸೇರಿಸುವ ಮೂಲಕ ಪ್ರಾರಂಭಿಸಿ.',
      cameraFeed: 'ಕ್ಯಾಮೆರಾ ಫೀಡ್',
      status: 'ಸ್ಥಿತಿ',
      location: 'ಸ್ಥಳ',
      streamType: 'ಸ್ಟ್ರೀಮ್ ಪ್ರಕಾರ'
    },
    settings: {
      title: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
      language: 'ಭಾಷಾ ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
      system: 'ಸಿಸ್ಟಂ ಆದ್ಯತೆಗಳು',
      camera: 'ಕ್ಯಾಮೆರಾ ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
      maxFps: 'ಗರಿಷ್ಠ FPS',
      autoLoad: 'ಸ್ವಯಂಚಾಲಿತ ಲೋಡ್ ಕ್ಯಾಮೆರಾಗಳು',
      autoLoadDesc: 'ಸ್ಟಾರ್ಟ್‌ಅಪ್‌ನಲ್ಲಿ ಕಾನ್ಫಿಗ್ ಫೈಲ್‌ನಿಂದ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕ್ಯಾಮೆರಾಗಳನ್ನು ಲೋಡ್ ಮಾಡಿ',
      recordingFormat: 'ಡೀಫಾಲ್ಟ್ ರೆಕಾರ್ಡಿಂಗ್ ಫಾರ್ಮ್ಯಾಟ್',
      storage: 'ಸಂಗ್ರಹಣಾ ಸ್ಥಳ',
      theme: 'ಥೀಮ್',
      apply: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಅನ್ವಯಿಸಿ',
      applying: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಅನ್ವಯಿಸಲಾಗುತ್ತಿದೆ...',
      success: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಅನ್ವಯಿಸಲಾಗಿದೆ',
      error: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಅನ್ವಯಿಸಲು ವಿಫಲವಾಗಿದೆ'
    },
    common: {
      online: 'ಆನ್‌ಲೈನ್',
      offline: 'ಆಫ್‌ಲೈನ್',
      error: 'ದೋಷ',
      save: 'ಉಳಿಸಿ',
      cancel: 'ರದ್ದುಮಾಡಿ',
      delete: 'ಅಳಿಸಿ',
      edit: 'ಸಂಪಾದಿಸಿ',
      history: 'ಇತಿಹಾಸ',
      recordings: 'ರೆಕಾರ್ಡಿಂಗ್‌ಗಳು',
      export: 'ರಫ್ತು',
      import: 'ಆಮದು',
      apply: 'ಅನ್ವಯಿಸಿ'
    }
  },
  malayalam: {
    dashboard: {
      title: 'ക്യാമറ ഡാഷ്ബോർഡ്',
      addCamera: 'ക്യാമറ ചേർക്കുക',
      noCameras: 'ക്യാമറകളൊന്നുമില്ല',
      getStarted: 'പുതിയ ക്യാമറ ചേർത്ത് ആരംഭിക്കുക.',
      cameraFeed: 'ക്യാമറ ഫീഡ്',
      status: 'സ്റ്റാറ്റസ്',
      location: 'സ്ഥാനം',
      streamType: 'സ്ട്രീം തരം'
    },
    settings: {
      title: 'ക്രമീകരണങ്ങൾ',
      language: 'ഭാഷാ ക്രമീകരണങ്ങൾ',
      system: 'സിസ്റ്റം മുൻഗണനകൾ',
      camera: 'ക്യാമറ ക്രമീകരണങ്ങൾ',
      maxFps: 'പരമാവധി FPS',
      autoLoad: 'സ്വയം ലോഡ് ക്യാമറകൾ',
      autoLoadDesc: 'സ്റ്റാർട്ടപ്പിൽ കോൺഫിഗ് ഫയലിൽ നിന്ന് സ്വയമേവ ക്യാമറകൾ ലോഡ് ചെയ്യുക',
      recordingFormat: 'സ്ഥിര റെക്കോർഡിംഗ് ഫോർമാറ്റ്',
      storage: 'സംഭരണ സ്ഥാനം',
      theme: 'തീം',
      apply: 'ക്രമീകരണങ്ങൾ പ്രയോഗിക്കുക',
      applying: 'ക്രമീകരണങ്ങൾ പ്രയോഗിക്കുന്നു...',
      success: 'ക്രമീകരണങ്ങൾ വിജയകരമായി പ്രയോഗിച്ചു',
      error: 'ക്രമീകരണങ്ങൾ പ്രയോഗിക്കുന്നതിൽ പരാജയപ്പെട്ടു'
    },
    common: {
      online: 'ഓൺലൈൻ',
      offline: 'ഓഫ്‌ലൈൻ',
      error: 'പിശക്',
      save: 'സേവ് ചെയ്യുക',
      cancel: 'റദ്ദാക്കുക',
      delete: 'ഇല്ലാതാക്കുക',
      edit: 'എഡിറ്റ് ചെയ്യുക',
      history: 'ചരിത്രം',
      recordings: 'റെക്കോർഡിംഗുകൾ',
      export: 'കയറ്റുമതി',
      import: 'ഇറക്കുമതി',
      apply: 'പ്രയോഗിക്കുക'
    }
  },
  gujarati: {
    dashboard: {
      title: 'કેમેરા ડેશબોર્ડ',
      addCamera: 'કેમેરા ઉમેરો',
      noCameras: 'કોઈ કેમેરા નથી',
      getStarted: 'નવો કેમેરા ઉમેરીને શરૂ કરો.',
      cameraFeed: 'કેમેરા ફીડ',
      status: 'સ્થિતિ',
      location: 'સ્થાન',
      streamType: 'સ્ટ્રીમ પ્રકાર'
    },
    settings: {
      title: 'સેટિંગ્સ',
      language: 'ભાષા સેટિંગ્સ',
      system: 'સિસ્ટમ પસંદગીઓ',
      camera: 'કેમેરા સેટિંગ્સ',
      maxFps: 'મહત્તમ FPS',
      autoLoad: 'સ્વયં લોડ કેમેરા',
      autoLoadDesc: 'સ્ટાર્ટઅપ પર કૉન્ફિગ ફાઇલમાંથી આપમેળે કેમેરા લોડ કરો',
      recordingFormat: 'ડિફૉલ્ટ રેકૉર્ડિંગ ફૉર્મેટ',
      storage: 'સ્ટોરેજ સ્થાન',
      theme: 'થીમ',
      apply: 'સેટિંગ્સ લાગુ કરો',
      applying: 'સેટિંગ્સ લાગુ કરી રહ્યા છીએ...',
      success: 'સેટિંગ્સ સફળતાપૂર્વક લાગુ કરવામાં આવી',
      error: 'સેટિંગ્સ લાગુ કરવામાં નિષ્ફળ'
    },
    common: {
      online: 'ઓનલાઇન',
      offline: 'ઓફલાઇન',
      error: 'ભૂલ',
      save: 'સાચવો',
      cancel: 'રદ કરો',
      delete: 'કાઢી નાખો',
      edit: 'સંપાદિત કરો',
      history: 'ઇતિહાસ',
      recordings: 'રેકૉર્ડિંગ્સ',
      export: 'નિકાસ',
      import: 'આયાત',
      apply: 'લાગુ કરો'
    }
  }
};