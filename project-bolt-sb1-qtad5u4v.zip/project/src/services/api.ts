const API_BASE_URL = 'http://localhost:5000';

export const api = {
  async checkCameras() {
    const response = await fetch(`${API_BASE_URL}/check_cameras`);
    return response.json();
  },

  async addCamera(camera: {
    source: string | number;
    name: string;
    max_fps: number;
  }) {
    const response = await fetch(`${API_BASE_URL}/add_camera`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(camera),
    });
    return response.json();
  },

  async removeCamera(cameraId: number) {
    const response = await fetch(`${API_BASE_URL}/remove_camera/${cameraId}`, {
      method: 'POST',
    });
    return response.json();
  },

  async listCameras() {
    const response = await fetch(`${API_BASE_URL}/list_cameras`);
    return response.json();
  },

  async startRecording(cameraId: number) {
    const response = await fetch(`${API_BASE_URL}/start_recording`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ camera_id: cameraId }),
    });
    return response.json();
  },

  async stopRecording(cameraId: number) {
    const response = await fetch(`${API_BASE_URL}/stop_recording`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ camera_id: cameraId }),
    });
    return response.json();
  },

  async listRecordings(cameraId: number) {
    const response = await fetch(`${API_BASE_URL}/recordings/${cameraId}`);
    return response.json();
  },
};