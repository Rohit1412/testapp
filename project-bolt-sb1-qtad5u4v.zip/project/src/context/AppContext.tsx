import React, { createContext, useContext, useState, useEffect } from 'react';
import { Camera, Recording, HistoryEvent, SystemConfig, Language } from '../types';
import { api } from '../services/api';

interface AppContextType {
  cameras: Camera[];
  recordings: Recording[];
  history: HistoryEvent[];
  config: SystemConfig;
  addCamera: (camera: Omit<Camera, 'id' | 'status'>) => void;
  removeCamera: (id: string) => void;
  updateConfig: (config: Partial<SystemConfig>) => void;
  setLanguage: (lang: Language) => void;
  addHistoryEvent: (event: Omit<HistoryEvent, 'id' | 'timestamp'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [history, setHistory] = useState<HistoryEvent[]>([]);
  const [config, setConfig] = useState<SystemConfig>({
    language: 'english',
    autoLoadCameras: true,
    defaultRecordingFormat: 'mp4',
    storageLocation: 'local',
    theme: 'light',
    maxFps: 20,
  });

  useEffect(() => {
    // Load data from localStorage on mount
    const savedConfig = localStorage.getItem('config');
    const savedHistory = localStorage.getItem('history');

    if (savedConfig) setConfig(JSON.parse(savedConfig));
    if (savedHistory) setHistory(JSON.parse(savedHistory));

    // Load cameras from API
    loadCameras();
  }, []);

  useEffect(() => {
    // Save data to localStorage when it changes
    localStorage.setItem('config', JSON.stringify(config));
    localStorage.setItem('history', JSON.stringify(history));
  }, [config, history]);

  const loadCameras = async () => {
    try {
      const response = await api.listCameras();
      if (response.status === 'success') {
        setCameras(response.cameras.map((cam: any) => ({
          id: cam.id.toString(),
          name: cam.name,
          ipAddress: cam.source,
          username: '',
          password: '',
          streamType: 'RTSP',
          location: '',
          description: '',
          status: cam.is_recording ? 'online' : 'offline',
        })));
      }
    } catch (error) {
      console.error('Failed to load cameras:', error);
    }
  };

  const addCamera = async (camera: Omit<Camera, 'id' | 'status'>) => {
    try {
      const response = await api.addCamera({
        source: camera.ipAddress,
        name: camera.name,
        max_fps: config.maxFps,
      });

      if (response.status === 'success') {
        const newCamera: Camera = {
          ...camera,
          id: response.camera_id.toString(),
          status: 'online',
        };
        setCameras([...cameras, newCamera]);
        addHistoryEvent({
          cameraId: newCamera.id,
          eventType: 'config',
          description: `Added new camera: ${camera.name}`,
        });
      }
    } catch (error) {
      console.error('Failed to add camera:', error);
      addHistoryEvent({
        cameraId: '0',
        eventType: 'error',
        description: `Failed to add camera: ${camera.name}`,
      });
    }
  };

  const removeCamera = async (id: string) => {
    try {
      const response = await api.removeCamera(parseInt(id));
      if (response.status === 'success') {
        setCameras(cameras.filter(cam => cam.id !== id));
        addHistoryEvent({
          cameraId: id,
          eventType: 'config',
          description: `Removed camera: ${cameras.find(c => c.id === id)?.name}`,
        });
      }
    } catch (error) {
      console.error('Failed to remove camera:', error);
    }
  };

  const updateConfig = (newConfig: Partial<SystemConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  };

  const setLanguage = (lang: Language) => {
    updateConfig({ language: lang });
  };

  const addHistoryEvent = (event: Omit<HistoryEvent, 'id' | 'timestamp'>) => {
    const newEvent: HistoryEvent = {
      ...event,
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
    };
    setHistory(prev => [newEvent, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        cameras,
        recordings,
        history,
        config,
        addCamera,
        removeCamera,
        updateConfig,
        setLanguage,
        addHistoryEvent,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};